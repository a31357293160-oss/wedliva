import { redirect } from "next/navigation";

export default function Home() {
  redirect("/invite/ayesha-danish");
}
